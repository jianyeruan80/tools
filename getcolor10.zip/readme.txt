
 GetColor! 1.01 for Win 9x/NT/2000 
       (c) Mar Software 2003-2004.        
   URL:    www.wincatalog.com/getcolor.html   
   E-Mail: support@wincatalog.com           
 
GetColor! allows to easily retrieve the color of any pixel on your desktop:
Just move the eyedropper tool into the any place of your desktop and GetColor!
shows you the color value!

The main features of GetColor!:

	- retrieve the color of any pixel on your desktop;
	- represent the color into most useful forms: HEX, RGB, HTML and WinAPI constant;
	- ability to minimize to tray;
	- ability to close to tray;
	- ability to start minimized;
	- ability to copy color value to clipboard;
	- ability to show the current mouse coordinates; 

---
WinCatalog.com - organizes any data on your PC!
http://www.wincatalog.com 